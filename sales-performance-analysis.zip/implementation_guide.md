We need to implement a python program to analyze sales data.

The example input data is raw_data_example.xlsx.

The goal is to identify the top 10 sales person in terms of total sales amoutn in all quarters. We find top 10 for each Geo group: AP, BRAZIL, EMEA, LAS, MX, NA.

One output example is:

AP			
(blank)	 $1.51 	 $1.01 	 $2.52 
Sudarat Rakbamrung	 $0.10 	 $1.80 	 $1.90 
Rachel Chiew	 $0.81 	 $0.07 	 $0.88 
Martin Lo	 $0.33 	 $0.33 	 $0.65 
Hemang Majmudar	 $0.50 	 $-0.00 	 $0.50 
Stella Djajasaputra	 $0.40 	 $0.06 	 $0.46 
Jason Loke J H	 $0.19 	 $0.12 	 $0.31 
Kok Hou Lee	 $0.13 	 $0.18 	 $0.31 
Cindy Ling	 $0.14 	 $0.17 	 $0.31 
Regino Enriquez	 $0.30 		 $0.30 
AP Total	 $4.40 	 $3.73 	 $8.13 

The program needs two parameters , the input excel file and the output excel file. it needs to write the output to a new tab in the output excel file,

Use lightweight libraries that easy to depoly and run on Windows laptop.



